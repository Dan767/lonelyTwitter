package ca.ualberta.cs.lonelytwitter.models;

public class Circle extends GraphObject {

    public void draw() {

    }

}
